const { conectar } = require("./utils/conexao");
const comandos = require("./comandos");
const config = require("./config/bot.config");

(async () => {
    const sock = await conectar();

    sock.ev.on("messages.upsert", async ({ messages }) => {
        for (const msg of messages) {
            if (msg.key.fromMe) continue;

            const args = msg.message.conversation.split(" ");
            const comando = args[0];

            if (config.comandosPublicos.includes(comando)) {
                await comandos.publico(msg, args);
            } else if (config.comandosAdmin.includes(comando) && config.donos.includes(msg.sender.id)) {
                await comandos.admin(msg, args);
            } else {
                await msg.reply("Desculpe, não entendi esse comando.");
            }
        }
    });

    console.log("Bot iniciado com sucesso!");
})();
