const { default: makeWASocket, useMultiFileAuthState } = require("@whiskeysockets/baileys");
const config = require("../config/bot.config");

module.exports = {
    conectar: async () => {
        const { state, saveCreds } = await useMultiFileAuthState("auth_info");
        const sock = makeWASocket({
            auth: state,
            printQRInTerminal: true,
            logger: {
                level: "warn",
                transport: {
                    console: () => ({ log: console.log })
                }
            }
        });

        sock.ev.on("connection.update", (update) => {
            const { connection, lastDisconnect } = update;
            if (connection === "close") {
                const shouldReconnect =
                    (lastDisconnect.error as any)?.output?.statusCode !== DisconnectReason.loggedOut;
                console.log("connection closed due to ", lastDisconnect.error, ", reconnecting ", shouldReconnect);

                if (shouldReconnect) {
                    this.conectar();
                }
            } else if (connection === "open") {
                console.log("opened connection");
            }
        });

        sock.ev.on("creds.update", saveCreds);
        return sock;
    }
};
