const config = require("../config/bot.config");

class GrupoManager {
    async criarGrupo(msg, args) {
        if (!config.donos.includes(msg.sender.id)) {
            await msg.reply("Desculpe, apenas os donos do bot podem criar grupos.");
            return;
        }

        const nome = args.join(" ");
        const grupo = await msg.createGroup(nome, [msg.sender.id]);
        await msg.reply(`Grupo "${nome}" criado com sucesso!`);
    }

    async fecharGrupo(msg, args) {
        if (!config.donos.includes(msg.sender.id)) {
            await msg.reply("Desculpe, apenas os donos do bot podem fechar grupos.");
            return;
        }

        const grupo = await msg.getChatById(args[0]);
        await grupo.clearMessages();
        await grupo.delete();
        await msg.reply(`Grupo "${grupo.name}" foi encerrado.`);
    }

    async adicionarMembro(msg, args) {
        if (!config.donos.includes(msg.sender.id)) {
            await msg.reply("Desculpe, apenas os donos do bot podem adicionar membros.");
            return;
        }

        const grupo = await msg.getChatById(args[0]);
        const membro = args[1];
        await grupo.addParticipants([membro]);
        await msg.reply(`Membro "${membro}" adicionado ao grupo "${grupo.name}".`);
    }

    async removerMembro(msg, args) {
        if (!config.donos.includes(msg.sender.id)) {
            await msg.reply("Desculpe, apenas os donos do bot podem remover membros.");
            return;
        }

        const grupo = await msg.getChatById(args[0]);
        const membro = args[1];
        await grupo.removeParticipants([membro]);
        await msg.reply(`Membro "${membro}" removido do grupo "${grupo.name}".`);
    }
}

module.exports = new GrupoManager();
