const config = require("../config/bot.config");
const { Configuration, OpenAIApi } = require("openai");

class IA {
    constructor() {
        this.configuration = new Configuration({
            apiKey: config.openAIApiKey
        });
        this.openai = new OpenAIApi(this.configuration);
    }

    async responder(mensagem) {
        try {
            const response = await this.openai.createCompletion({
                model: "text-davinci-003",
                prompt: mensagem,
                max_tokens: 2048,
                temperature: 0.7
            });

            return response.data.choices[0].text;
        } catch (error) {
            console.error(error);
            return "Desculpe, não foi possível gerar uma resposta.";
        }
    }

    async treinar(tema, conteudo) {
        try {
            await this.openai.createCompletion({
                model: "text-davinci-003",
                prompt: `Treine a IA do bot com o seguinte tema e conteúdo:\n\nTema: ${tema}\nConteúdo: ${conteudo}`,
                max_tokens: 2048,
                temperature: 0.7
            });
        } catch (error) {
            console.error(error);
        }
    }
async adicionarRespostaRapida(palavra, resposta) {
        try {
            const config = require("../config/bot.config");
            config.respostasRapidas[palavra] = resposta;
            return `Resposta rápida adicionada para a palavra "${palavra}": "${resposta}"`;
        } catch (error) {
            console.error(error);
            return "Desculpe, não foi possível adicionar a resposta rápida.";
        }
    }

    async removerRespostaRapida(palavra) {
        try {
            const config = require("../config/bot.config");
            delete config.respostasRapidas[palavra];
            return `Resposta rápida removida para a palavra "${palavra}".`;
        } catch (error) {
            console.error(error);
            return "Desculpe, não foi possível remover a resposta rápida.";
        }
    }
}

module.exports = new IA();
