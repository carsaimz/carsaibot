const { Usuario, Ranking } = require("../database/models");

class Rankings {
    async exibirRankings() {
        const rankings = await Ranking.findAll({
            order: [["valor", "DESC"]],
            limit: 10
        });

        let mensagem = "*Top 10 Rankings*\n\n";
        for (let i = 0; i < rankings.length; i++) {
            const ranking = rankings[i];
            const usuario = await Usuario.findByPk(ranking.userId);
            mensagem += `#${i + 1} - ${usuario.nome} - ${ranking.valor} ${ranking.tipo}\n`;
        }
        return mensagem;
    }

    async atualizarRanking(userId, tipo, valor) {
        let ranking = await Ranking.findOne({ where: { userId, tipo } });
        if (!ranking) {
            ranking = await Ranking.create({ userId, tipo, valor });
        } else {
            ranking.valor = valor;
            await ranking.save();
        }
    }
}

module.exports = new Rankings();
