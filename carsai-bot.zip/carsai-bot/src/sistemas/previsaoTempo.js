const axios = require("axios");
const config = require("../config/bot.config");

class PrevisaoTempo {
    async obterPrevisao(cidade) {
        try {
            const response = await axios.get(`http://api.openweathermap.org/data/2.5/weather?q=${cidade}&appid=${config.openWeatherApiKey}&units=metric&lang=pt_br`);
            const { name, weather, main } = response.data;
            return `
*Previsão do Tempo para ${name}*
Condição: ${weather[0].description}
Temperatura: ${main.temp}°C
Umidade: ${main.humidity}%
`;
        } catch (error) {
            console.error(error);
            return "Desculpe, não foi possível obter a previsão do tempo.";
        }
    }
}

module.exports = new PrevisaoTempo();
