const { Usuario } = require("../database/models");
const rankings = require("./rankings");

class Niveis {
    async subirNivel(userId, xp) {
        const usuario = await Usuario.findByPk(userId);
        if (!usuario) return;

        usuario.xp += xp;
        const proximoNivel = this.calcularProximoNivel(usuario.nivel);
        if (usuario.xp >= proximoNivel) {
            usuario.nivel++;
            await msg.reply(`Parabéns, você subiu para o nível ${usuario.nivel}!`);
        }
        await usuario.save();

        await rankings.atualizarRanking(userId, "nivel", usuario.nivel);
    }

    async exibirPerfil(userId) {
        const usuario = await Usuario.findByPk(userId);
        if (!usuario) {
            return "Você precisa se cadastrar primeiro.";
        }
        return `
*Seu Perfil*
Nome: ${usuario.nome}
Nível: ${usuario.nivel}
XP: ${usuario.xp}
Compras: ${usuario.compras}
Vendas: ${usuario.vendas}
Interações: ${usuario.interacoes}
Última Interação: ${usuario.ultimaInteracao}
Cidade: ${usuario.cidade}
Premium: ${usuario.premium ? "Sim" : "Não"}
`;
    }

    calcularProximoNivel(nivel) {
        return Math.floor(4 * Math.pow(nivel, 2.2));
    }
}

module.exports = new Niveis();
