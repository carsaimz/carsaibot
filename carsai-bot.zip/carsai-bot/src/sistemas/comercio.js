const { Usuario, Ranking } = require("../database/models");
const niveis = require("./niveis");

class Comercio {
    async exibirCatalogo() {
        // Lógica para exibir o catálogo de produtos
        return `
*Catálogo de Produtos*
1. Carro Usado - 1000 XP
2. Moto Usada - 500 XP
3. Bicicleta - 200 XP
`;
    }

    async comprar(msg, args) {
        const usuario = await Usuario.findByPk(msg.sender.id);
        if (!usuario) {
            await msg.reply("Você precisa se cadastrar primeiro.");
            return;
        }

        const produtoId = parseInt(args[0]);
        const produto = this.getCatalogo()[produtoId - 1];
        if (!produto) {
            await msg.reply("Produto inválido.");
            return;
        }

        if (usuario.xp < produto.preco) {
            await msg.reply("Você não tem XP suficiente para comprar esse produto.");
            return;
        }

        usuario.xp -= produto.preco;
        usuario.compras++;
        await usuario.save();

        await niveis.subirNivel(usuario.id, produto.xp);
        await msg.reply(`Você comprou o produto "${produto.nome}" por ${produto.preco} XP.`);
    }

    async vender(msg, args) {
        const usuario = await Usuario.findByPk(msg.sender.id);
        if (!usuario) {
            await msg.reply("Você precisa se cadastrar primeiro.");
            return;
        }

        const produtoId = parseInt(args[0]);
        const produto = this.getCatalogo()[produtoId - 1];
        if (!produto) {
            await msg.reply("Produto inválido.");
            return;
        }

        usuario.xp += produto.preco;
        usuario.vendas++;
        await usuario.save();

        await niveis.subirNivel(usuario.id, produto.xp);
        await msg.reply(`Você vendeu o produto "${produto.nome}" por ${produto.preco} XP.`);
    }

    getCatalogo() {
        return [
            { id: 1, nome: "Carro Usado", preco: 1000, xp: 500 },
            { id: 2, nome: "Moto Usada", preco: 500, xp: 250 },
            { id: 3, nome: "Bicicleta", preco: 200, xp: 100 }
        ];
    }
}

module.exports = new Comercio();
