const config = require("../config/bot.config");
const ia = require("../sistemas/ia");
const previsaoTempo = require("../sistemas/previsaoTempo");
const rankings = require("../sistemas/rankings");
const niveis = require("../sistemas/niveis");
const comercio = require("../sistemas/comercio");
const grupoManager = require("../sistemas/grupoManager");
const menus = require("../menus/menus");

const comandos = {
    publico: async (msg, args) => {
        const comando = args[0];
        switch (comando) {
            case "catalogo":
                await msg.reply(await comercio.exibirCatalogo());
                break;
            case "ranking":
                await msg.reply(await rankings.exibirRankings());
                break;
            case "perfil":
                await msg.reply(await niveis.exibirPerfil(msg.sender.id));
                break;
            case "ia":
                await msg.reply(await ia.responder(args.slice(1).join(" ")));
                break;
            case "tempo":
                await msg.reply(await previsaoTempo.obterPrevisao(args[1]));
                break;
            case "suporte":
                await msg.reply("Entre em contato com o grupo de suporte: " + config.grupoSuporte);
                break;
            case "adicionarrespostarapida":
                if (args.length < 3) {
                    await msg.reply("Uso incorreto do comando. Use: adicionarrespostarapida <palavra> <resposta>");
                    return;
                }

                const palavra = args[1];
                const resposta = args.slice(2).join(" ");
                const resultadoAdicionar = await ia.adicionarRespostaRapida(palavra, resposta);
                await msg.reply(resultadoAdicionar);
                break;
            case "removerrespostarapida":
                if (args.length < 2) {
                    await msg.reply("Uso incorreto do comando. Use: removerrespostarapida <palavra>");
                    return;
                }

                const palavraRemover = args[1];
                const resultadoRemover = await ia.removerRespostaRapida(palavraRemover);
                await msg.reply(resultadoRemover);
                break;
            default:
                await msg.reply("Desculpe, não entendi esse comando.");
        }
    },

    admin: async (msg, args) => {
        const comando = args[0];
        switch (comando) {
            case "config":
                await msg.reply(await this.exibirConfiguracoes());
                break;
            case "stats":
                await msg.reply(await this.exibirEstatisticas());
                break;
            case "ia_treino":
                await ia.treinar(args[1], args.slice(2).join(" "));
                await msg.reply("IA treinada com sucesso!");
                break;
            case "testes":
                await this.executarTestes();
                await msg.reply("Testes concluídos!");
                break;
            case "grupos":
                await this.gerenciarGrupos(msg, args.slice(1));
                break;
            case "usuarios":
                await this.gerenciarUsuarios(msg, args.slice(1));
                break;
            case "broadcast":
                await this.enviarBroadcast(args.slice(1).join(" "));
                await msg.reply("Broadcast enviado com sucesso!");
                break;
            default:
                await msg.reply("Desculpe, não entendi esse comando.");
        }
    },

    async adicionarRespostaRapida(palavra, resposta) {
        try {
            config.respostasRapidas[palavra] = resposta;
            return `Resposta rápida adicionada para a palavra "${palavra}": "${resposta}"`;
        } catch (error) {
            console.error(error);
            return "Desculpe, não foi possível adicionar a resposta rápida.";
        }
    },

    async removerRespostaRapida(palavra) {
        try {
            delete config.respostasRapidas[palavra];
            return `Resposta rápida removida para a palavra "${palavra}".`;
        } catch (error) {
            console.error(error);
            return "Desculpe, não foi possível remover a resposta rápida.";
        }
    }
};

module.exports = comandos;