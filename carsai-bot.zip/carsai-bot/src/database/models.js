const { Sequelize, DataTypes } = require("sequelize");

const sequelize = new Sequelize({
    dialect: "sqlite",
    storage: "./database/database.sqlite"
});

// Usuários
const Usuario = sequelize.define("Usuario", {
    id: {
        type: DataTypes.STRING,
        primaryKey: true
    },
    nome: DataTypes.STRING,
    nivel: {
        type: DataTypes.INTEGER,
        defaultValue: 1
    },
    xp: {
        type: DataTypes.INTEGER,
        defaultValue: 0
    },
    compras: {
        type: DataTypes.INTEGER,
        defaultValue: 0
    },
    vendas: {
        type: DataTypes.INTEGER,
        defaultValue: 0
    },
    interacoes: {
        type: DataTypes.INTEGER,
        defaultValue: 0
    },
    ultimaInteracao: DataTypes.DATE,
    cidade: DataTypes.STRING,
    premium: {
        type: DataTypes.BOOLEAN,
        defaultValue: false
    }
});

// Sistema de IA
const IADados = sequelize.define("IADados", {
    entrada: DataTypes.STRING,
    resposta: DataTypes.STRING,
    contexto: DataTypes.STRING,
    usado: {
        type: DataTypes.INTEGER,
        defaultValue: 0
    }
});

// Rankings
const Ranking = sequelize.define("Ranking", {
    userId: DataTypes.STRING,
    tipo: DataTypes.STRING,
    pontos: DataTypes.INTEGER,
    posicao: DataTypes.INTEGER
});

// Previsão do Tempo
const PrevisaoTempo = sequelize.define("PrevisaoTempo", {
    cidade: DataTypes.STRING,
    temperatura: DataTypes.FLOAT,
    condicao: DataTypes.STRING,
    umidade: DataTypes.INTEGER,
    atualizadoEm: DataTypes.DATE
});

module.exports = {
    sequelize,
    Usuario,
    IADados,
    Ranking,
    PrevisaoTempo
};
