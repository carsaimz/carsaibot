module.exports = {
    nome: "CarsaiBot Commerce",
    versao: "1.0.0",
    prefix: "!",
    donos: [
        "258844414345@s.whatsapp.net",
        "258862414345@s.whatsapp.net"
    ],
    autor: "CarsaiMz",
    developer: "CarsaiDev",
    criador: "Carimo Saide Mpinda",
    grupoSuporte: "120363025255836758@g.us",
    comunidade: "120363025255836758@g.us"
}
