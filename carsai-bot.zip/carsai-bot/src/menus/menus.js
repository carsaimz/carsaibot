module.exports = {
    principal: {
        titulo: "🚗 *MENU CARSAIBOT COMMERCE* 🤖",
        botoes: [
            ["📚 Catálogo", "🏆 Rankings"],
            ["👤 Meu Perfil", "🌤️ Previsão"],
            ["📞 Suporte", "ℹ️ Sobre"]
        ]
    },
    
    admin: {
        titulo: "👑 *PAINEL ADMINISTRATIVO* 👑",
        botoes: [
            ["⚙️ Configurações", "📊 Estatísticas"],
            ["🤖 Treinar IA", "👥 Usuários"],
            ["🔒 Grupos", "📢 Broadcast"]
        ]
    },
    
    rankings: {
        titulo: "🏆 *RANKINGS CARSAI* 🏆",
        botoes: [
            ["🥇 Top 3", "🏅 Top 5"],
            ["📈 Top 10", "🌟 Top Geral"],
            ["↩️ Voltar"]
        ]
    },

    footer: "\n\n📱 Autor: CarsaiMz\n💻 Dev: CarsaiDev\n👨‍💻 By: Carimo Saide Mpinda"
}
